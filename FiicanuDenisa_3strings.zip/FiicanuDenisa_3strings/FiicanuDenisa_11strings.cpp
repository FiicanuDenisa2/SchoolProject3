#include<iostream>
#include<stdio.h>
#include<string.h>
#include<string>
using namespace std;

int main()
{
    char a[50][50],temp1[50],temp2[50],c[50][50],b[50][50];
    char n[50][50];
    char m[50][50];
    int i,j,k,d=0,y=0;
    n[0][0]='s'; n[0][1]='t'; n[0][2]='o'; n[0][3]='p';
    while(d!=4)
    {
        cout<<"Introduceti cuvantul: ";
        gets(m[y]);
        d=0;
        for(i=0;i<4;i++)
            if(m[y][i]==n[0][i])
                d++;
        if(d!=4)
        {
            strcpy(a[y], m[y]);
            y++;
        }
    }
    for(k=0,i=0;k<=y,i<=y;k++,i++)
        strcpy(c[k],a[i]);
    for(i=0;i<=y;i++)
        strcpy(b[i],a[i]);
    for(i=0;i<=y;i++)
        strlwr(a[i]);
    for (i=0;i<=y;i++)
    {
        for (j=i+1;j<=y;j++)
        {
            if (strcmp(a[i], a[j]) > 0)
            {
                strcpy(temp1, a[i]);
                strcpy(a[i], a[j]);
                strcpy(a[j], temp1);
                strcpy(temp2, c[i]);
                strcpy(c[i], c[j]);
                strcpy(c[j], temp2);
            }
        }
    }
    int x=0;
    for(i=0;i<=y;i++)
        {
            if(strcmp(b[0],c[i])==0)
                {
                    x=1;
                    j=i;
                    break;
                }
            else x=0;
        }
    cout<<endl;
    if(x==1)
        for(j=i+1;j<=y;j++)
            puts(c[j]);
}
