#include<fstream>
#include<stdio.h>
#include<string.h>
using namespace std;

ifstream fin("text.in");
ofstream fout("text.out");

int main()
{
    int n;
    char a[50][50];
    char b[50];
    char c;
    fin>>n;
    for(int i=0;i<=n;i++)
    fin.getline(a[i],50);
    for(int i=1;i<=n;i++)
    {
        strcpy(b,a[i]);
        b[0]=toupper(b[0]);
        for(int j=1;j<strlen(b);j++)
            b[j]=tolower(b[j]);
        for(int j=0;j<strlen(b);j++)
            if(isspace(b[j]))
                b[j+1]=toupper(b[j+1]);
    fout<<b<<" "<<endl;
    }
    fin.close();
    fout.close();
}
