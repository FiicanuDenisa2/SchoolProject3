#include<fstream>
#include<stdio.h>
#include<string.h>
using namespace std;

ifstream fin("text.in");
ofstream fout("text.out");

int main()
{
    char a[50];
    fin.get(a,50);
    int i,j;
    char b[50];
    strcpy(b,a);
    for (i=0,j=0;i<strlen(a);i++,j++)
    {
        if (a[i]!=' ')
            b[j]=a[i];
        else
            if(a[i]==' ' && isspace(a[i-1])==0)
                b[j]=a[i];
        else
            j--;
    }
    b[j]=0;
    for(i=0;i<strlen(b);i++)
        fout<<b[i];
    fin.close();
    fout.close();
}
