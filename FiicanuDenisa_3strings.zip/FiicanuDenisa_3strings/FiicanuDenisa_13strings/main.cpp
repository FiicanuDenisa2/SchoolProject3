#include<fstream>
#include<stdio.h>
#include<string.h>
using namespace std;
char a[50], b[50]; int i;

ifstream fin("text.in");
ofstream fout("text.out");
void gotonextword()
{
    while(isspace(b[i])==0 && ispunct(b[i])==0 && b[i]!=0)
        i++;
}

int main()
{
    char *pch;
    fin.get(a,50);
    strcpy(b,a);
    int x;
    char c[50][50];
    int k=0;
    int j=0,w=0;
    pch=strtok (a," ,.-");
    while (pch!=NULL)
    {
        i=0;
        while(i<strlen(b))
        {
            if(b[i]==pch[0])
            {
                for(j=0;j<strlen(pch);j++)
                {
                    if(b[i+j]!=pch[j])
                    {
                        gotonextword();
                        break;
                    }
                }
                if(j==strlen(pch))
                {
                    if(isspace(b[i+j]) || ispunct(b[i+j]) || b[i+j]==0  )
                    {
                        w++;
                        i=i+j;
                    }
                }
            }
            else gotonextword();
            i++;
        }
        if(w>x)
        {
            strcpy(c[k],pch);
            k++;
        }
        fout<<pch<<" "<<w<<endl;
        x=w;
        pch=strtok(NULL," ,.-");
        w=0;
    }
    for(int l=0;l<k;l++)
        fout<<c[l]<<endl;
    fin.close();
    fout.close();
}
